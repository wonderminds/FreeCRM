package com.amazon.utils;

public class Testutil {

	public static long page_load_timeout=30;
	public static long implicit_wait=10;
	
	
}
