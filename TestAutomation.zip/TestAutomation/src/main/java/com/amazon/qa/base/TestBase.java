package com.amazon.qa.base;

import java.io.FileInputStream;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.firefox.FirefoxDriver;


import com.amazon.utils.Testutil;

public class TestBase {
	
	public static WebDriver wd;
	public static Properties prop;
	
public TestBase() throws IOException {
	try {
		prop= new Properties();
		FileInputStream fin= new FileInputStream("C:\\Users\\dell\\my-workspace\\TestAutomation\\src\\main\\java\\com\\amazon\\qa\\config\\Config.properties");
		prop.load(fin);
		
	}
	catch(FileNotFoundException ex) {
		ex.printStackTrace();
		}
	catch(IOException e) {
		e.printStackTrace();
	}
}
public static void initialization() {
   String browser= prop.getProperty("browser");
   if(browser.equalsIgnoreCase("chrome")) {
	   System.setProperty("webdriver.chrome.driver", "C:\\Useful_SW\\ChromeV91\\ChromeV91.0.4472.106\\chromedriver.exe");
//	   ChromeOptions opt = new ChromeOptions();
//	   opt.addArguments("--incognito");
//	   opt.addArguments("--remote-debugging-port=8080");
	   wd= new ChromeDriver();
	   }
   else if(browser.equalsIgnoreCase("FF")) {
	   System.setProperty("webdriver.gecko.driver","C:\\Useful_SW\\geckodriver.exe");
	   wd= new FirefoxDriver();  
	   }
	wd.manage().window().maximize();
	wd.manage().deleteAllCookies();
	wd.manage().timeouts().pageLoadTimeout(Testutil.page_load_timeout, TimeUnit.SECONDS);
	wd.manage().timeouts().implicitlyWait(Testutil.implicit_wait, TimeUnit.SECONDS);
	wd.get(prop.getProperty("url"));
   }
}
