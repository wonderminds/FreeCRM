package com.amazon.qa.pages;

import org.apache.poi.hssf.eventusermodel.dummyrecord.LastCellOfRowDummyRecord;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Homepage {
	
	
	@FindBy(xpath="//div[@id='branding']/a[2]")
	WebElement Welcome_user;
	
	@FindBy(xpath="//*[@id=\"dashboard-quick-launch-panel-menu_holder\"]/table/tbody/tr/td[1]/div/a/span")
	WebElement Assign_leave;
	
	@FindBy(xpath="//input[@name='assignleave[txtEmployee][empName]']")
	WebElement emp_name;
	
	@FindBy(xpath="//select[@id='assignleave_txtLeaveType']")
	WebElement Leave_type;
	
	@FindBy(xpath="//input[@id='assignleave_txtFromDate']")
	WebElement from_dt;
	
	@FindBy(xpath="//input[@id='assignleave_txtToDate']")
	WebElement to_dt;
	
	@FindBy(id="assignBtn")
	WebElement Assign_btn;
	
	public void display_username() {
		System.out.println(Welcome_user.getText());
		
	}
	
	
	
	public void assign_leave() {
	Assign_leave.click();
	emp_name.sendKeys("Prateek");
	Select sc1= new Select(Leave_type);
	sc1.selectByIndex(3);
	from_dt.sendKeys("2021-06-10");
	to_dt.sendKeys("2021-06-12");
		
		
	}
	
}
