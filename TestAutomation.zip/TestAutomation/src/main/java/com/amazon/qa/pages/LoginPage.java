package com.amazon.qa.pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.amazon.qa.base.TestBase;

public class LoginPage extends TestBase{
	
//PageFactory:- OR
	
	@FindBy(xpath="//img[@src='/webres_6051af48107ce6.31500353/themes/default/images/login/logo.png']")
	WebElement crm_logo;
	
	@FindBy(id="txtUsername")
	WebElement Username;
	
	@FindBy(id="txtPassword")
	WebElement Password;
    
	@FindBy(id="btnLogin")
	WebElement login_btn;
	
	
	public LoginPage() throws IOException{
		PageFactory.initElements(wd, this);
		
	}
	
	
	public String validate_title() {
	  return wd.getTitle();
		
	}
	
	public boolean validate_logo() {
		return crm_logo.isDisplayed();
	}
	
	
	public Homepage login(String uname,String pwd)
	{
		Username.sendKeys(uname);
		Password.sendKeys(pwd);
		login_btn.click();
	   	return new Homepage();
	}


	
	
	
	
}
