package com.amazon.qa.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.*;

import io.cucumber.java.en.When;
public class TestData {
	
	WebDriver wd;

	public void read_excel() throws IOException {
		
//		File f1= new File("C:\\Users\\dell\\Downloads\\kanta madaan mam.xlsx");
//		FileInputStream fs= new FileInputStream(f1);
//		Workbook wk=null;
//		wk= new XSSFWorkbook(fs);
//		String sheetname="Sheet1";
//		org.apache.poi.ss.usermodel.Sheet sh1=  wk.getSheet(sheetname);
//		int rowcount= sh1.getLastRowNum()-sh1.getFirstRowNum();
//		
//		System.out.println("Excel is having"+ rowcount + "rows");
		System.setProperty("webdriver.chrome.driver","C:\\Useful_SW\\chrome_V90\\chromedriver.exe");
		wd= new ChromeDriver();
		wd.navigate().to("https://www.facebook.com");
		
	}
@When(value = "^user logs in using Username and Password") 
	public void enter_uname_Pwd(String arg1, String arg2) {
	
	wd.findElement(By.id("email")).sendKeys(arg1);
	wd.findElement(By.id("pass")).sendKeys(arg2);
	wd.findElement(By.name("login")).click();
	
	
}
	public static void main(String []ar) {
		
		try {
			TestData td= new TestData();
			td.read_excel();
			td.enter_uname_Pwd("8130437648", "Wisdombeyond@123");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
}
