package com.amazon.testcases;

import java.io.IOException;
import java.util.Arrays;

import org.testng.asserts.*;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.amazon.qa.base.TestBase;
import com.amazon.qa.pages.Homepage;
import com.amazon.qa.pages.LoginPage;

import junit.framework.Assert;

public class LoginPageTest extends TestBase {
	
	LoginPage lp;
	public LoginPageTest() throws IOException {
		super();
		// TODO Auto-generated constructor stub
		
	}

	@BeforeMethod
	public void setup() throws IOException {
		initialization();
		lp= new LoginPage();
	}
	
	@SuppressWarnings("deprecation")
	@Test(enabled=true,priority=1)
	public void validate_Login_Page_Title() {
	String title= lp.validate_title();
	Assert.assertEquals("OrangeHRM", title);
	System.out.println(title);
	}
	@Test(enabled=false)
 	@SuppressWarnings("deprecation")
    public void validate_Login_Image() {
		boolean flag= lp.validate_logo();
     	System.out.println(flag);
 		boolean exp= Boolean.parseBoolean("true");
		Assert.assertEquals(exp,flag);	
	}
	String uname=prop.getProperty("username");
	String pwd= prop.getProperty("password");
	@SuppressWarnings("deprecation")
	@Test(priority=2)
	public void validate_login() throws IOException {
		Homepage hp= lp.login(uname,pwd);
		Assert.assertEquals(new Homepage().getClass(), hp.getClass());
//		String loggedin_user= lp.fetch_username();
//		String[] log_user= loggedin_user.split("",1);
//		System.out.println("You are currently logged in as: "+ log_user[0]);
		
	}
	
	
	@AfterMethod
	public void teardown() {
		wd.close();
		}	

}
