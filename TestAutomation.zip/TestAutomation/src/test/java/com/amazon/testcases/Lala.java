package com.amazon.testcases;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import com.amazon.qa.base.TestBase;
import com.amazon.qa.pages.LoginPage;

import io.cucumber.java.en.Given;

public class Lala extends TestBase {

	LoginPage lp1; 
	public Lala() throws IOException {
		super();
		
	}
	public void set_up() throws IOException {
		initialization();
		lp1 = new LoginPage();
		
	}
	
	@Given("^When user is already on login page$")
	public void validate_page_title() {
	  
		
	}
	
}
