package com.amazon.testcases;






import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;
import java.util.Dictionary;
import java.util.*;
public class Amazon {
	
	

	
	WebDriver dr;
	@Test(priority=1)
	public void operate() {
		String search_product= "Bose speakers";
		System.setProperty("webdriver.gecko.driver","C:\\\\Useful_SW\\\\geckodriver.exe");
		dr = new FirefoxDriver();
		dr.navigate().to("https://www.amazon.in");
		WebDriverWait wt= new WebDriverWait(dr,30);
		wt.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='nav-logo-sprites']")));
		dr.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys(search_product);
		dr.findElement(By.xpath("//input[@id='nav-search-submit-button']")).click();
		dr.findElement(By.xpath("//*[@id=\"p_89/Bose\"]/span/a/span")).click();
		
		List<WebElement>  product_title= dr.findElements(By.xpath("//a[@class='a-link-normal a-text-normal']"));
	
		List<WebElement> product_prices = null;
		
		product_prices= dr.findElements(By.xpath("//*[@class='a-price-whole']"));
		System.out.println(product_title);
		System.out.println(product_prices);
		int count =0;
		List l2= new ArrayList();
		List l3= new ArrayList();
	    for(WebElement e : product_title){
//			System.out.println(e.getText());
			l2.add(e.getText());	
			}
	     for(WebElement e1: product_prices) {
	    	 l3.add(e1.getText());
	    	 
	     }
//	     Collections.sort(l3);
	     Dictionary<Object, Object> dict= new Hashtable<Object, Object>(); 
		int length= l2.size();
	    for(int i=0;i<length;i++) {
//	    	System.out.print(l2.get(i));
//	    	System.out.print(l3.get(i));
//	    	System.out.println("");
           dict.put(l2.get(i), l3.get(i));
          }
        System.out.println(dict);
	    
	
	}
		
		}
	
