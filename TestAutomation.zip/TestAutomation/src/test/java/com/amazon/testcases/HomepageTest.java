package com.amazon.testcases;

import java.io.IOException;


import org.testng.annotations.*;
import com.amazon.qa.base.TestBase;
import com.amazon.qa.pages.Homepage;
import com.amazon.qa.pages.LoginPage;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.io.File;
import org.apache.commons.io.FileUtils;
public class HomepageTest extends TestBase {

	WebDriver driver;
	Homepage hp;
	LoginPage lp2;
	
	public HomepageTest() throws IOException {
		
		super();
		
	}
   @Test(enabled=true)
   public void show() throws IOException {
	   String name= "Admin";
	   String pwd= "admin123";
	   System.out.println("Calling the login method");
	   TestBase.initialization();
	   lp2.login(name, pwd);	
     
   }
//	

	

	@Test(dependsOnMethods = {"show"})
    public void retrieve_username() {
   	hp.display_username();
	}
//	@Test(enabled=false)
//	public void Assign_leave() {
//		hp.assign_leave();
//		
//	}
  


}
